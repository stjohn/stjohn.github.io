#!/usr/bin/env python3

import numpy as np

from aido_schemas import EpisodeStart, protocol_agent_duckiebot1, PWMCommands, Duckiebot1Commands, LEDSCommands, RGB, wrap_direct, Context, Duckiebot1Observations, JPGImage


class RandomAgent:

    def init(self, context: Context):
        self.n = 0
        #Set up variables to keep track of the average red, green, and blue values:
        self.red = 0
        self.green = 0
        self.blue = 0
        context.info('init()')

    def on_received_seed(self, data: int):
        np.random.seed(data)

    def on_received_episode_start(self, context: Context, data: EpisodeStart):
        context.info(f'Starting episode "{data.episode_name}".')

    def on_received_observations(self,  data: Duckiebot1Observations):
        camera: JPGImage = data.camera
        _rgb = jpg2rgb(camera.jpg_data)
        #Compute the average red, green, and blue values of the image:
        self.red = int(np.mean(_rgb[:,:,0]))
        self.green = int(np.mean(_rgb[:,:,1]))
        self.blue = int(np.mean(_rgb[:,:,2]))

    def on_received_get_commands(self, context: Context):
        #Don't move for now, just use the camera to collect data:
        #pwm_left = 0.5
        #pwm_right = 0.5
        #Print out the averages:
        s = "red: " +str(self.red)+"\tgreen: " + str(self.green) + "\tblue: "+ str(self.blue)
        context.info(s)

        grey = RGB(0.0, 0.0, 0.0)
        led_commands = LEDSCommands(grey, grey, grey, grey, grey)
        pwm_commands = PWMCommands(motor_left=pwm_left, motor_right=pwm_right)
        commands = Duckiebot1Commands(pwm_commands, led_commands)
        context.write('commands', commands)

    def finish(self, context: Context):
        context.info('finish()')

def jpg2rgb(image_data: bytes) -> np.ndarray:
    """ Reads JPG bytes as RGB"""
    from PIL import Image
    import io
    im = Image.open(io.BytesIO(image_data))
    im = im.convert('RGB')
    data = np.array(im)
    assert data.ndim == 3
    assert data.dtype == np.uint8
    return data


def main():
    node = RandomAgent()
    protocol = protocol_agent_duckiebot1
    wrap_direct(node=node, protocol=protocol)


if __name__ == '__main__':
    main()
