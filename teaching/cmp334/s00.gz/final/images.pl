# LaTeX2HTML 98.1 release (February 19th, 1998)
# Associate images original text with physical files.


1;

