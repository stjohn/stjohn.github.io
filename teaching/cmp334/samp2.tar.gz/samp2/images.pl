# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


$key = q/{_inline}frac12{_inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="13" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$\frac{1}{2}$">|; 

1;

