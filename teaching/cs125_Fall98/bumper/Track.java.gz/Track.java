
import ccj.*;

public class Track
{
    Track() { ... }
    public void drive() { ... }
    public void draw() { ... }

    private BumperCar Fred0;
    private BumperCar Fred9;
}
