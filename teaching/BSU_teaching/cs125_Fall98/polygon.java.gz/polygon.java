// Draws up to an n-sided polygon
// It uses the GraphicsApplet from ccj.*

import ccj.*;

public class polygon extends GraphicsApplet
{
    public void run()
    {
	int radius = 5;

	int n = readInt("Enter number of sides:");
	Point[] polygon = new Point[n];
		
	// Calculate points:
	for ( int i = 0 ; i < n ; i++ )
	{
	    double theta = i * (2*Math.PI/n);
	    double x = radius * Math.cos(theta);
	    double y = radius * Math.sin(theta);
	    polygon[i] = new Point(x, y);
	}	

	// Draw polygon:
	for ( int i = 0 ; i < n ; i++ )
	{
	    polygon[i].draw();
	    new Line(polygon[i], polygon[(i+1)%n]).draw();
	}
    }
}
