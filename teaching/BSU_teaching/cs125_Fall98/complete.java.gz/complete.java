// Draws the complete graph on n points
// It uses the GraphicsApplet from ccj.*

import ccj.*;

public class complete extends GraphicsApplet
{
    public void run()
    {
	int radius = 5;

	int n = readInt("Enter number of points:");
	Point[] polygon = new Point[n];
		
	// Calculate points:
	for ( int i = 0 ; i < n ; i++ )
	{
	    double theta = i * (2*Math.PI/n);
	    double x = radius * Math.cos(theta);
	    double y = radius * Math.sin(theta);
	    polygon[i] = new Point(x, y);
	}	

	// Draw the complete graph:
	for ( int i = 0 ; i < n ; i++ )
	{
	    for ( int j = i+1 ; j < n ; j++ )
	    {
	    	polygon[i].draw();
	    	new Line(polygon[i], polygon[j%n]).draw();
	    }
	}
    }
}
