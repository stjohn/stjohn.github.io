/****************************************************************************
** COPYRIGHT (C):    1996 Cay S. Horstmann. All Rights Reserved.
** PROJECT:          Computing Concepts with Java
** FILE:             Coins2.java
****************************************************************************/

public class Coins2
{  public static void main(String[] args)
   {  System.out.print("Total value = ");
      System.out.println(8 * 0.01 + 4 * 0.10 + 3 * 0.25);
   }
}
