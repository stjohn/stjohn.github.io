/**
 * From _Java in a Nutshell_ by David Flanagan, 
 *      Copyrighted by O'Reilly and Associates, 1996.
 *
 * This program does simple animation.
 */

import java.applet.*;
import java.awt.*;
import java.net.*;
import java.util.*;

public class animate2 extends Applet implements Runnable
{
    protected Image[] images;	//Array that stores the images
    protected int current_image;//The index of image being displayed
    private Button start_button;
    private Button stop_button;
    private int current_speed = 1000;  //Current color of drawing pen
    private Choice speed_choices;

    //Get the name of the images.  Assumes that all the image names
    //begin the same, for example "group", and then loads the pictures
    //group1.jpg, group2.jpg,...  The parameter basename contains
    //the beginning of the name.  The parameter num_images contains
    //the number of images.
    public void init()
    {
    	String basename = this.getParameter("basename");
	int num_images;
	try {
	    num_images = Integer.parseInt(this.getParameter("num_images"));
	}
	catch (NumberFormatException e) {
	    num_images = 0;
	}

	images = new Image[num_images];
	for (int i = 1 ; i <= num_images ; i++)
	{
	    images[i-1] = this.getImage(this.getDocumentBase(), 
	    		basename + i + ".jpg");
	}

  
        // Create a button and add it to the graphics window
        stop_button = new Button("stop");//Make the label also say "stop"
        stop_button.setForeground(Color.black);
        stop_button.setBackground(Color.lightGray);
        this.add(stop_button);            //Necessary to use the button

        // Create a button and add it to the graphics window
        start_button = new Button("start");//Make the label also say "start"
        start_button.setForeground(Color.black);
        start_button.setBackground(Color.lightGray);
        this.add(start_button);            //Necessary to use the button

        // Create choices with items for the colors and add it to
        // the graphics window
        speed_choices = new Choice();
        speed_choices.addItem("slow");
        speed_choices.addItem("medium");
        speed_choices.addItem("fast");
        speed_choices.setForeground(Color.black);
        speed_choices.setBackground(Color.lightGray);
        //this.add(new Label("Color: "));
        this.add(speed_choices);
    }

    //This is the thread that runs the animation and the 
    //methods that start and stop it:
    private Thread animate_thread = null;

    public void start()
    {
    	if (animate_thread == null)
	{
	    animate_thread = new Thread(this);
	    animate_thread.start();
	}
    }

    public void stop()
    {
    	if ((animate_thread != null) && animate_thread.isAlive())
	{
	    animate_thread.stop();
	}

	//Set to null, so, it can be picked up by garbage collection
	animate_thread = null;
    }

    //Here's what the thread does:
    public void run()
    {
    	while (true)
	{
	    current_image++;
	    if (current_image == images.length)
	    	current_image = 0;
	    this.getGraphics().drawImage(images[current_image],0,0,this);
	    try {
	    	Thread.sleep(current_speed);
	    }
	    catch (InterruptedException e) { ; }
	}
    }

    public boolean action(Event event, Object arg) 
    {
        // If the Clear button was clicked, clear the graphics window
        if (event.target == start_button) {
	    this.start();
            return true;
        }
        if (event.target == stop_button) {
	    this.stop();
            return true;
        }
        else if (event.target == speed_choices) {
            if (arg.equals("slow")) current_speed = 1000;
            else if (arg.equals("medium")) current_speed = 500;
            else if (arg.equals("fast")) current_speed = 100;
            return true;
        }
        // Otherwise, let the superclass handle it.
        else return super.action(event, arg);
    }
}


