
import ccj.*;

public class BumperCar
{
    BumperCar() { ... }
    BumperCar(int label) { ... }
    BumperCar(int label, int x, int y) { ... }

    public void draw() { ... }
    public void move(int direction) { ... }

    public int getX() { ... }
    public int getY() { ... }

    private int label;
    private int x;
    private int y;
}
