/* 
 * This program tests to see if a word is palindrome.
 */

import ccj.*;

public class palindrome
{  public static void main(String[] args)
   {  System.out.print("Please enter a word: ");
      String s = Console.in.readWord();
      boolean isPal = pal(s);
      System.out.println("\n"+isPal);
   }


   /**
    * true if s is a palindrome
    * @param s a string
    * @return true if a palindrome, false otherwise
    **/
   public static boolean pal(String s)
   {
      int n = s.length();
      
      if ( (n==0) || (n==1) )    // Stopping condition
         return true;
      else if ( s.substring(0,1).equals(s.substring(n-1,n)) )
         //Check the next two letters:
         return pal(s.substring(1,n-1));  
      else
         //The outer letters don't match, so return false
         return false;
   }
}


