# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}A&&B{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.gif"
 ALT="$A\&\&B$">|; 

$key = q/{inline}8%3*5-16slash3*4{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="155" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img4.gif"
 ALT="$8 \% 3 * 5 - 16/3 * 4$">|; 

$key = q/{inline}990%100{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img3.gif"
 ALT="$990 \% 100$">|; 

$key = q/{inline}!(A&&B){inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="83" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$!(A\&\&B)$">|; 

1;

