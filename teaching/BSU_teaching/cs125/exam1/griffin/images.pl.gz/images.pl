# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}displaystyleb^2-4ac{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="img2.gif"
 ALT="$\displaystyle{b^2 - 4ac}$">|; 

$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img4.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{inline}displaystylesqrtfrac11+frac1x{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="66" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="img3.gif"
 ALT="$\displaystyle{\sqrt{\frac{1}{1 + \frac{1}{x}}}}$">|; 

$key = q/{inline}displaystylefrac1a+b{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="54" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$\displaystyle{\frac{1}{a + b}}$">|; 

1;

