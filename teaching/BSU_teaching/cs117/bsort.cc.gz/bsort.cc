#include <iostream.h>

/* Bubble sort 
 *    For i=0 to length, compare the ith element to the 
 *	(i+1)th element.  If it's larger, swap them.  
 *	This places the largest element in the last position.
 *	Repeating this, places the second largest element
 *	in the second to last position.  So, repeat this
 *	length times until they're all in order.
 */

void sort(int a[], int start, int finish);
void swap(int& x, int& y);

int main()
{
  int length;
  cout << "Enter the number of elements to sort: ";
  cin >> length;
  int nums[length];
  
  for ( int i = 0 ; i < length ; i++ )
    cin >> nums[i];

  sort(nums, 0, length);
  
  cout << "\nThe sorted list is: ";
  for ( int i = 0 ; i < length ; i++ )
    cout << nums[i] << " ";
  cout << endl;

  return(0);
}

void sort(int a[], int start, int finish)
{
  //Repeat the bubbling finish-start times:
  for (int i = start ; i < finish ; i++)
  {
    //Bubble the largest element to the top:
    for (int j = start ; j+1 < finish ; j++)
    {
      if ( a[j] > a[j+1] )
	swap(a[j],a[j+1]);	
    }
  }
  return;
}

void swap(int& x, int& y)
{
  int temp;
  temp = x;
  x = y;
  y = temp;
  
  return;
}

