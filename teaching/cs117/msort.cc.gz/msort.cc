#include <iostream.h>

/* Merge sort
 *    Divide the list in half, sort each list, and then
 *	merge the lists back together.
 *    (This sort uses recursion). 
 */

void sort(int a[], int start, int finish);
void merge(int a[], int start, int mid, int finish);

int main()
{
  int length;
  cout << "Enter the number of elements to sort: ";
  cin >> length;
  int nums[length];
  
  for ( int i = 0 ; i < length ; i++ )
    cin >> nums[i];

  sort(nums, 0, length);
  
  cout << "\nThe sorted list is: ";
  for ( int i = 0 ; i < length ; i++ )
    cout << nums[i] << " ";
  cout << endl;

  return(0);
}

void sort(int a[], int start, int finish)
{
  if ( finish-start > 1 )
  {
    int mid = (finish+start)/2;	//Halfway point

    //Sort each half:
    sort(a,start,mid);
    sort(a,mid,finish); 

    //Merge the halfs back together:
    merge(a,start,mid,finish);
  }
}

void merge(int a[], int start, int mid, int finish)
{
  int b[finish-start];	//Hold the numbers while merging
  int i=start,		//Counter for 1st half
      j=mid,		//Counter for 2nd half
      k=0;		//Counter for merged part

  while ( k < finish-start )
  {
    if ( ( j >= finish ) || 
	( ( i < mid ) && ( a[i] < a[j] ) ) )
    {
      //The first element in first half is smaller
      b[k] = a[i];
      k++;
      i++;
    }  
    else
    {
      //The first element in second half is smaller
      b[k] = a[j];
      k++;
      j++;
    }
  } 

  //Copy b (the temporary copy) into a:
  for ( k = 0 ; k < finish-start ; k++ )
    a[start+k] = b[k];

  return;
}

