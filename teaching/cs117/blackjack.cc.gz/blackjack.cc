#include <iostream.h>
#include <stdlib.h>	// To use random number generation

class Blackjack
{
  public:
    Blackjack();	// default constructor
    void print();
    void addCard(int newCard);	

  private:
    int card1;		// Stores the number value of each
    int card2;		// card.
    int card3;
    int card4;
    int card5;
    int numcards;	// Keeps track of the number of cards
			// currently stored.
};

int main()
{
  Blackjack player1, player2;
  int nextCard;
  char answer;
  bool again1 = true, 	// True if player1 wants another turn
	again2 = true; 	// True if player2 wants another turn

  do {

    if ( again1 )
    {
      cout << endl << "Player 1: do you want a card? ";
      cin >> answer;
      if ( ( answer == 'y' ) || ( answer == 'Y' ) )
      {
	nextCard = rand()%10 + 1;	// Counting Aces as 1's.
        cout << "Your next card is " << nextCard
		<< ".\n";
	player1.addCard(nextCard);
	cout << "Your current cards are: ";
        player1.print();
	cout << endl;
      }
      else 	// They don't want to play anymore
	again1 = false;
    }

    if ( again2 )
    {
      cout << endl << "Player 2: do you want a card? ";
      cin >> answer;
      if ( ( answer == 'y' ) || ( answer == 'Y' ) )
      {
	nextCard = rand()%10 + 1;	// Counting Aces as 1's.
        cout << "Your next card is " << nextCard
		<< ".\n";
	player2.addCard(nextCard);
	cout << "Your current cards are: ";
        player2.print();
	cout << endl;
      }
      else 	// They don't want to play anymore
	again2 = false;
    }

  } while ( again1 || again2 );
  
  cout << endl << endl << "Final results:\n";
  cout << "Player 1 has ";
  player1.print();
  cout << "Player 2 has ";
  player2.print();
  cout << endl << "Thank you for playing!\n\n";

  return(0);
}


// The default constructor.  This is called to set the initial 
// hand, so, we need to set the number of cards to 0.

Blackjack::Blackjack()
{
  numcards = 0;
}


// addCard takes an integer and stores it in the first free
// card.

void Blackjack::addCard(int newCard)
{
  switch (numcards)
  {
    case 0:
      card1 = newCard;
      numcards++;
      break;
    case 1:
      card2 = newCard;
      numcards++;
      break;
    case 2:
      card3 = newCard;
      numcards++;
      break;
    case 3:
      card4 = newCard;
      numcards++;
      break;
    case 4:
      card5 = newCard;
      numcards++;
      break;
    default:
      cout << "Error: Hand is full";
  }   
}


// print() prints out the value of the cards, separated
// by spaces.

void Blackjack::print()
{
  switch (numcards)
  {
    case 0:
      break;
    case 1:
      cout << card1;
      break;
    case 2:
      cout << card1 << " " << card2 << endl;
      break;
    case 3:
      cout << card1 << " " << card2 << " " << card3 << endl;
      break;
    case 4:
      cout << card1 << " " << card2 << " " << card3 << " " << card4 << endl;
      break;
    case 5:
      cout << card1 << " " << card2 << " " << card3 << " " << card4 << " "
	<< card5 << endl;
      break;
    default:
      cout << "Error in number of cards";
  }   
}

