
select * from employee;
select * from department;
select * from dept_locations;
select * from works_on;
select * from project;
select * from dependent;
