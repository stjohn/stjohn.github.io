import java.io.*;
public class Mystery4B
{  public static void main(String[] args)
   {  try
      {  BufferedReader inputStream = 
             new BufferedReader(new FileReader("story.txt"));
         PrintWriter outputStream =
             new PrintWriter(new FileOutputStream("storylines.txt"));
         int count = 0;
         String line = inputStream.readLine();
         while (line != null)
         {  count = line.length();
            outputStream.println(count + " " + line);
            line = inputStream.readLine(); 
         }
	 System.out.println("The end."); 
         inputStream.close();
         outputStream.close();
      }
      catch(FileNotFoundException e)
      {  System.out.println("File story.txt not found."); }
      catch(IOException e2)
      {  System.out.println("Error reading from file story.txt."); }
   }
}


