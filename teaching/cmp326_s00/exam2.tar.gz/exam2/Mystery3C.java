import java.awt.*; 
import java.awt.event.*;

public class Mystery3C extends Frame 
{
    // The constants used in this program:
    public static final int WIDTH = 300;   
    public static final int HEIGHT = 200;
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 100;

    public static void main(String[] args)
    {
        Mystery3C demo  = new Mystery3C();
        demo.setVisible(true);
    }

    public Mystery3C()
    {
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
    }

    public void paint(Graphics g)
    {
	g.setColor(Color.black);
        for ( int i = 0 ; i < 8 ; i++ )
	{
	    int x1 = (int)(Math.cos(2*Math.PI*i/8)*RADIUS+XCENTER); 
	    int y1 = (int)(Math.sin(2*Math.PI*i/8)*RADIUS+YCENTER); 
	    int x2 = (int)(Math.cos(2*Math.PI*(i+1)/8)*RADIUS+XCENTER); 
	    int y2 = (int)(Math.sin(2*Math.PI*(i+1)/8)*RADIUS+YCENTER); 
	    g.drawLine(x1, y1, x2, y2);
	}
    }
}
