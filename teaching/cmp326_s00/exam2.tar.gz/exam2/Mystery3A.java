import java.awt.*; 
import java.awt.event.*;

public class Mystery3A extends Frame 
{
    public static final int WIDTH = 300;   
    public static final int HEIGHT = 200;

    public static void main(String[] args)
    {
        Mystery3A demo  = new Mystery3A();
        demo.setVisible(true);
    }

    public Mystery3A()
    {
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
    }

    public void paint(Graphics g)
    {
	g.setColor(Color.black);
	g.drawRect(10,10,150,100);
    }
}
