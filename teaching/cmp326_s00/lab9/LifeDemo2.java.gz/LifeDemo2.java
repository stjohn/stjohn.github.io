import java.awt.*; 
import java.awt.event.*;

/*
 * This program plays the game of life.  The color of each cell 
 * is stored in an array, called displayColor.  The size of 
 * displayColor is WIDTH/10 by HEIGHT/10.
 */

public class LifeDemo2 extends Frame implements ActionListener
{
    // The constants used in this program:
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    public static void main(String[] args)
    {
        LifeDemo2 ColorDemo  = new LifeDemo2();
        ColorDemo.setVisible(true);
    }

    // The default contructor sets up the textField, label
    // and button.  It also sets background colors and 
    // registers the listeners.
    public LifeDemo2()
    {
	// Set up the frame with title, size, and the 
	// listener for the close button:
        setTitle("The Game of Life");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());

	// Allocate space for the cells:
        displayColor = new Color[WIDTH/10][HEIGHT/10];
	initArray(displayColor);

	// Buttons and panel-- the listener is this object
        textPanel = new Panel(); 
        textPanel.setBackground(Color.gray);

	Button nextButton = new Button("Next");
	nextButton.setBackground(Color.lightGray);
	nextButton.addActionListener(this);
	textPanel.add(nextButton);

	Button resetButton = new Button("Reset");
	resetButton.setBackground(Color.lightGray);
	resetButton.addActionListener(this);
	textPanel.add(resetButton);

        add(textPanel, "South");
    }

    // If the done button is pushed, get the integer from the 
    // textField theText and call repaint to draw the pie to the
    // screen.
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Next"))
	{
		//Reset all the colors:
		for (int i = 1; i < WIDTH/10-1 ; i++)
		{
	    	    for (int j = 1; j < HEIGHT/10-1;  j++)
	    	    {
			int nbors = neighbors( i, j );
			if ( displayColor[i][j].equals(Color.white) )
			{
			    if ( nbors == 3 )	    
			        displayColor[i][j] = Color.green;
			}
			else
			{
			    if ( nbors < 2 || nbors > 4)
			        displayColor[i][j] = Color.white;
			    else if ( displayColor[i][j] == Color.green )
			        displayColor[i][j] = Color.blue;
			}
	    	    }
		}
		
	}
        else if (e.getActionCommand().equals("Reset"))
	{
	    initArray(displayColor);
        }
        repaint();//Shows changes in textPanel
    } 

    // Paint the pie and its pieces to the screen:
    public void paint(Graphics g)
    {
	for (int i = 0 ; i < WIDTH/10 ; i++)
	{
            for (int j = 0; j < HEIGHT/10 ; j++)
            {
		g.setColor(displayColor[i][j]);
		g.fillRect(i*10,j*10,10,10);
	    }
	}
    }

    private void initArray(Color[][] cArray)
    {
	for (int i = 0; i < WIDTH/10 ; i++)
	{
	    for (int j = 0; j < HEIGHT/10 ; j++)
	    {
		if ( Math.random() > .1 )
		    displayColor[i][j] = Color.white;
		else
		    displayColor[i][j] = Color.blue;
	    }
	}
    }
 

    private int neighbors( int i, int j)
    {
	int count = 0;
        if ( displayColor[i-1][j-1].equals(Color.blue))
	    count++;
        if ( displayColor[i-1][j].equals(Color.blue))
	    count++;
        if ( displayColor[i-1][j+1].equals(Color.blue))
	    count++;
        if ( displayColor[i][j-1].equals(Color.blue))
	    count++;
        if ( displayColor[i][j+1].equals(Color.blue))
	    count++;
        if ( displayColor[i+1][j-1].equals(Color.blue))
	    count++;
        if ( displayColor[i+1][j].equals(Color.blue))
	    count++;
        if ( displayColor[i+1][j+1].equals(Color.blue))
	    count++;
        return(count);
    }
 
    int red = 0;
    private Color[][] displayColor;
    private Panel textPanel;
    int numPieces = 0;
}
