 /*
Program 14
Author: Sandra Tinta
Date:  03/29/00
E-mail: violetadelosalpes@yahoo.com

 I, Sandra Tinta, pledge that this program is
 my own indepedent work and conforms to the academic
 honor code.*/

import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/**********************************************************
 * This applet will have a polygon drawn in the screen,
 **********************************************************/

public class PolygonApplet  extends Applet
{
    // The constants used in this applet
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 125;


    public void init()
    {
        // Set up thebackground
        setBackground(Color.gray);
        String sideString = getParameter("sides");
        nSides = Integer.valueOf(sideString).intValue();
     }

    /***********************************************************
    * If the done button is pushed, get the integer from the
    * textField theText and call repaint to draw the polygon
    * to the screen.
    ************************************************************/

    // Paint the polygon to the screen:
    public void paint(Graphics g)
    {
        // Make sure the pen color is black:
        g.setColor(Color.black);

        for ( int i = 0 ; i < nSides ; i++ )
        {
            int xCirc = (int)(Math.cos(2*Math.PI*i/nSides)*RADIUS+XCENTER);
            int yCirc = (int)(Math.sin(2*Math.PI*i/nSides)*RADIUS+YCENTER);

            int x2Circ = (int)(Math.cos(2*Math.PI*(i+1)/nSides)*RADIUS+XCENTER);
            int y2Circ = (int)(Math.sin(2*Math.PI*(i+1)/nSides)*RADIUS+YCENTER);

            g.drawLine(xCirc,yCirc, x2Circ, y2Circ);
        }
    }
 
    // A private method for drawing circles with center (xCenter,yCenter)
    // and radius rad.
    private void drawCircle(Graphics g, int xCenter, int yCenter, int rad)
    {
        g.drawOval(xCenter-rad, yCenter-rad, 2*rad, 2*rad);
    }
 

    int nSides = 0;
}

