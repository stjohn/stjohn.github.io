import java.applet.*;
import java.awt.*; 
import java.awt.event.*;

/*
 * This program prompts the user to enter the number of 
 * pieces to be drawn.  When the user clicks the "Done"
 * button, the pie is drawn to the screen.  
 *
 * There is no error checking to make sure the user enters
 * an integer.
 */

public class PolygonApplet extends Applet 
{
    // The constants used in this program:
    public static final int WIDTH = 300;   
    public static final int HEIGHT = 300;
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 125;


    public void init()
    {
	// Set up the frame with title, size, and the listener
	// for the close button:
        setLayout(new BorderLayout());
	setBackground(Color.lightGray);
	
	numPieces = Integer.valueOf(getParameter("num")).intValue();
 
    }

    // Paint the pie and its pieces to the screen:
    public void paint(Graphics g)
    {
	// Make sure the pen color is black:
	g.setColor(Color.black);

	// Draw the circle:
	//drawCircle(g, XCENTER, YCENTER, RADIUS);

	int oldx = (int)(Math.cos(0)*RADIUS+XCENTER); 
	int oldy = (int)(Math.sin(0)*RADIUS+YCENTER); 
	int newx, newy;
	// Draw each piece of the pie:
            for ( int j = 1 ; j <= numPieces ; j++)
            {
	        newx=(int)(Math.cos(2*Math.PI*j/numPieces)*RADIUS+XCENTER); 
	        newy=(int)(Math.sin(2*Math.PI*j/numPieces)*RADIUS+YCENTER); 
	        g.drawLine(oldx, oldy, newx, newy);
		oldx = newx; 
		oldy = newy;
	    }
    }
 
    // A private method for drawing circles with center (xCenter, yCenter)
    // and radius rad.
    private void drawCircle(Graphics g, int xCenter, int yCenter, int rad)
    {
	g.drawOval(xCenter-rad, yCenter-rad, 2*rad, 2*rad);
    }
 
    private Panel textPanel;
    private TextField theText;
    int numPieces = 0;
}
