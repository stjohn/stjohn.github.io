import java.awt.*;
import java.awt.event.*;

public class SecondWindow extends Frame
{
    public static final int WIDTH = 550;
    public static final int HEIGHT = 400;

    /**********************************************************
     *Creates and displays a window of the class SecondWindow.
     ***********************************************************/
    public static void main(String[] args)
    {
        SecondWindow myWindow = new SecondWindow();
        myWindow.setVisible(true);
    }

    public SecondWindow()
    {
        super();
        addWindowListener(new WindowDestroyer());
        setTitle("Second Window");
        setSize(WIDTH, HEIGHT);
        setBackground(Color.blue);
    }

    public void paint(Graphics g)
    {
        g.drawString("Coming to you in living color!", 10, 100);
    }
}
