import java.applet.*; 
import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a container class.
 ***************************************************************/
public class ScoreApplet extends Applet implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    /**********************************************************
     *Creates and displays a window of the class Score.
     ***********************************************************/

    public void init()
    {
        setBackground(Color.blue);
 
        setLayout(new FlowLayout());

        Button stopButton = new Button("Red"); 
        stopButton.addActionListener(this);
        add(stopButton);

        Button goButton = new Button("Green");
        goButton.addActionListener(this); 
        add(goButton);        
    }

    public void paint(Graphics g)
    {
        g.drawString(theText, 75, 100);
    }
 
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Red"))
       {
            setBackground(Color.red);
            redCount++; 
       }
       else if (e.getActionCommand().equals("Green"))
       {
           setBackground(Color.green);
           greenCount++;
       }
       else
           theText = "Error in button interface.";

       theText = "Red: " + redCount + "  Green: " + greenCount;
       repaint(); //force color and text change
    }
 
 
    private String theText = "Red: 0  Green: 0";
    private int redCount = 0;
    private int greenCount = 0;
}

