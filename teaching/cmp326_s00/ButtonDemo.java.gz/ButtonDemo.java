import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a container class.
 ***************************************************************/
public class ButtonDemo extends Frame implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    /**********************************************************
     *Creates and displays a window of the class ButtonDemo.
     ***********************************************************/
    public static void main(String[] args)
    {
        ButtonDemo buttonGui = new ButtonDemo();
        buttonGui.setVisible(true);
    }


    public ButtonDemo()
    {
        setSize(WIDTH, HEIGHT);

        addWindowListener(new WindowDestroyer()); 
        setTitle("Button Demonstration");
        setBackground(Color.blue);
 
        setLayout(new FlowLayout());

        Button stopButton = new Button("Red"); 
        stopButton.addActionListener(this);
        add(stopButton);

        Button goButton = new Button("Green");
        goButton.addActionListener(this); 
        add(goButton);        
    }

    public void paint(Graphics g)
    {
        g.drawString(theText, 75, 100);
    }
 
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Red"))
        {
            setBackground(Color.red);
            theText = "STOP"; 
        }
        else if (e.getActionCommand().equals("Green"))
        {
           setBackground(Color.green);
           theText = "GO";
        }
        else
            theText = "Error in button interface.";

       repaint(); //force color and text change
    }
 
 
    private String theText = "Watch me!";
}

