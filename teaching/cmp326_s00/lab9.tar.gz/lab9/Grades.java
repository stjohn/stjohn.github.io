
public class Grades
{
    public static void main(String[] args) 
    {
      	int [][] grades = new int[5][3];
	int i, j, grade, average;

	for (i = 0 ; i < 5 ; i++)
	{ 
            System.out.println("Enter exam scores for student "+(i+1)+": ");
            grades[i][0] = SavitchIn.readInt();
            grades[i][1] = SavitchIn.readInt();
            grades[i][2] = SavitchIn.readInt();
        }

        System.out.println("Grades and Averages:");
        System.out.println("\t\tExam 1\tExam 2\tFinal\tGrade");
	for (i = 0 ; i < 5 ; i++)
	{ 
	    grade = (int) 
		Math.max(.3*grades[i][0]+.3*grades[i][1]+.4*grades[i][2],
	    	Math.max(.3*grades[i][0]+.7*grades[i][2],
	        Math.max(.3*grades[i][1]+.7*grades[i][2], grades[i][2])));
            System.out.println("Student "+(i+1)+"\t"+ grades[i][0] + "\t" +
            	grades[i][1] + "\t" + grades[i][2] + "\t" +  grade);
        }
	System.out.print("\nAverages:");
	for (j = 0 ; j < 3 ; j++)
	{ 
	    average = 0;
	    for (i = 0; i < 5 ; i++)
	    { 
	        average += grades[i][j];
	    }
	    average = (int)(average/5.0);
            System.out.print("\t"+ average);
	}
	System.out.println();
    }
}

