import java.awt.*; 
import java.awt.event.*;

/*
 * This program plays the game of life.  The color of each cell 
 * is stored in an array, called displayColor.  Each cell is 10 pixels
 * by 10 pixels.  So, the size of displayColor is WIDTH/10 by HEIGHT/10,  
 * where WIDTH and HEIGHT are constants that control the size of the 
 * window.  The cells along the lower edge will not be visible, since
 * the panel with the buttons covers them.
 *
 * The rules for the game of life: if a vacant cell has exactly
 * 3 neighbors, then it becomes occupied.  If an occupied cell has 
 * less than 2 or more than 4 neighbors, it dies.
 */

public class LifeDemo extends Frame implements ActionListener
{
    // The constants used in this program:
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;
    public static final Color OCCUPIED = Color.blue;
    public static final Color VACANT = Color.white;

    public static void main(String[] args)
    {
        LifeDemo GameOfLife  = new LifeDemo();
        GameOfLife.setVisible(true);
    }

    // The default contructor sets up the buttons and
    // initializes the cells, by callling initArray().
    // It also sets background colors and registers 
    // the listeners.
    public LifeDemo()
    {
	// Set up the frame with title, size, and the 
	// listener for the close button:
        setTitle("The Game of Life");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());

	// Allocate space for the cells:
        displayColor = new Color[WIDTH/10][HEIGHT/10];
	initArray(displayColor);

	// Buttons and panel-- the listener is this object
        textPanel = new Panel(); 
        textPanel.setBackground(Color.gray);

	Button nextButton = new Button("Next");
	nextButton.setBackground(Color.lightGray);
	nextButton.addActionListener(this);
	textPanel.add(nextButton);

	Button resetButton = new Button("Reset");
	resetButton.setBackground(Color.lightGray);
	resetButton.addActionListener(this);
	textPanel.add(resetButton);

        add(textPanel, "South");

    }

    // If the next button is clicked, move one more turn, following
    // the rules (see top comment) of the game of life.  For simplicity,
    // ignore the cells along the edge.
    // If the reset button is clicked, re-initialize the array of cells.
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Next"))
	{
		//Reset all the colors:
		for (int i = 1; i < WIDTH/10-1 ; i++)
		{
	    	    for (int j = 1; j < HEIGHT/10-1;  j++)
	    	    {
			int nbors = neighbors( i, j );
			if ( displayColor[i][j].equals(VACANT) )
			{
			    if ( nbors == 3 )	    
			        displayColor[i][j] = OCCUPIED;
			}
			else
			{
			    if ( nbors < 2 || nbors > 4)
			        displayColor[i][j] = VACANT;
			}
	    	    }
		}
		
	}
        else if (e.getActionCommand().equals("Reset"))
	{
	    initArray(displayColor);
        }
        repaint();//Shows changes in textPanel
    } 

    // Paint the cells to the screen
    public void paint(Graphics g)
    {
	for (int i = 0 ; i < WIDTH/10 ; i++)
	{
            for (int j = 0; j < HEIGHT/10 ; j++)
            {
		g.setColor(displayColor[i][j]);
		g.fillRect(i*10,j*10,10,10);
	    }
	}
    }

    // Randomly, assign a color to every element of the 
    // array.  Most cells (90%) will be vacant.
    private void initArray(Color[][] cArray)
    {
	for (int i = 0; i < WIDTH/10 ; i++)
	{
	    for (int j = 0; j < HEIGHT/10 ; j++)
	    {
		if ( Math.random() > .1 )
		    displayColor[i][j] = VACANT;
		else
		    displayColor[i][j] = OCCUPIED;
	    }
	}
    }
 
    // Calculate the number of neighbors a cell has.  For 
    // simplicity, we only calculate this for cells away from
    // the borders.
    private int neighbors( int i, int j)
    {
	int count = 0;
        if ( displayColor[i-1][j-1].equals(OCCUPIED))
	    count++;
        if ( displayColor[i-1][j].equals(OCCUPIED))
	    count++;
        if ( displayColor[i-1][j+1].equals(OCCUPIED))
	    count++;
        if ( displayColor[i][j-1].equals(OCCUPIED))
	    count++;
        if ( displayColor[i][j+1].equals(OCCUPIED))
	    count++;
        if ( displayColor[i+1][j-1].equals(OCCUPIED))
	    count++;
        if ( displayColor[i+1][j].equals(OCCUPIED))
	    count++;
        if ( displayColor[i+1][j+1].equals(OCCUPIED))
	    count++;
        return(count);
    }
 
    private Color[][] displayColor;
    private Panel textPanel;
}
