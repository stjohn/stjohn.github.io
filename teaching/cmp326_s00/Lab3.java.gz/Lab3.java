import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 * Lab 3, CMP 326-1, Lehman College, CUNY
 * Spring 2000
 *
 * This program lets the user either draw a rectangle (by clicking
 * the "Rectangle" button) or clear the screen (by clicking the
 * "Clear" button).  The buttons are part of a panel that's added
 * to the "South" part of the Frame (the Frame is using the border
 * layout). 
 *
 * For today's lab, you need to add 2 more drawing choices for the
 * user: draw an oval and draw a face.  See the webpage for more
 * details.
 ***************************************************************/

public class Lab3 extends Frame implements ActionListener
{
    // Width and height of the frame:
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    // The color of the background and of the buttons:
    private Color BGCOLOR = Color.blue;

    // The color in which the shapes are drawn:
    private Color FGCOLOR = Color.green;

    // What should be drawn next (default is rectangle):
    private String toDraw = "Rectangle";

    // Makes a new object that is visible to the user:
    public static void main(String[] args)
    {
        Lab3 guiWithPanel = new Lab3();
        guiWithPanel.setVisible(true);
    }

    // The default contructor sets up the frame, creates a panel
    // for the buttons, and registers the listeners.  A WindowDestroyer()
    // object listens for the close button, while the action events
    // are handled by the object itself (since Lab3 implements 
    // ActionListener).
    public Lab3()
    {
        // Set up the frame:
        setTitle("Lab 3-- Drawing Shapes");
        setSize(WIDTH, HEIGHT);
        setBackground(BGCOLOR); 
        addWindowListener(new WindowDestroyer());
   
        // Create a panel for the buttons:
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.white);
        buttonPanel.setLayout(new FlowLayout());

	// Create the buttons with this object as the listener
	// and add them to the panel:
        Button rButton = new Button("Rectangle");
        rButton.setBackground(BGCOLOR); 
        rButton.addActionListener(this);
        buttonPanel.add(rButton);

        Button cButton = new Button("Clear");
        cButton.setBackground(BGCOLOR);
        cButton.addActionListener(this); 
        buttonPanel.add(cButton);        

	//Set up the frame's layout and add in the panel:
        setLayout(new BorderLayout());
        add(buttonPanel, "South");
    }
 
    // Depending on the value of toDraw, paint() draws a 
    // rectangle to the screen, or clears the screen.
    public void paint(Graphics g)
    {
	if ( toDraw.equals("Rectangle") )
	{
	    g.setColor(FGCOLOR);
	    g.fillRect(20,20,100,100);
	}
	else if ( toDraw.equals("Clear") )
	{
	    g.setColor(BGCOLOR);   
	    g.clearRect(0,0,WIDTH, HEIGHT);
	}
	else
	    g.drawString(toDraw, 75,75);
    }
   
    // Currently, actionPerformed handles the action 
    // events from the Rectangle and Clear buttons.
    // Sets toDraw depending on which button is pushed.
    // paint() uses toDraw to decide what to draw next.
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Rectangle"))
       {
	   toDraw = "Rectangle";
       }
       else if (e.getActionCommand().equals("Clear"))
       {
           toDraw = "Clear";
       }
       else
           toDraw = "Error in button interface.";

       repaint(); //force color and text change
    }

}

