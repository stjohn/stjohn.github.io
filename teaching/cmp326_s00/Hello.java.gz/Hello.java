


/****************************************************************************
** COPYRIGHT (C):    1996 Cay S. Horstmann. All Rights Reserved.
** PROJECT:          Computing Concepts with Java
** FILE:             Hello.java
****************************************************************************/

public class Hello
{  public static void main(String[] args)
   {  String greeting = "Hello, World!\n";
      System.out.print(greeting);
   }
}



