import java.applet.*;
import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a panel. If you do
 *not see the colored part of the window with text in it, use your
 *mouse to increase the size of the window and it will appear.
 ***************************************************************/
public class Lab3Applet extends Applet implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    public void init()
    {
        setBackground(Color.blue); 
   
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.white);

        buttonPanel.setLayout(new FlowLayout());

        Button rButton = new Button("Rectangle");
        rButton.setBackground(Color.blue); 
        rButton.addActionListener(this);
        buttonPanel.add(rButton);

        Button oButton = new Button("Oval");
        oButton.setBackground(Color.blue); 
        oButton.addActionListener(this);
        buttonPanel.add(oButton);

        Button fButton = new Button("Face");
        fButton.setBackground(Color.blue); 
        fButton.addActionListener(this);
        buttonPanel.add(fButton);

        Button cButton = new Button("Clear");
        cButton.setBackground(Color.blue);
        cButton.addActionListener(this); 
        buttonPanel.add(cButton);        

        setLayout(new BorderLayout());
        add(buttonPanel, "South");
   }
 
    public void paint(Graphics g)
    {
	if ( toDraw.equals("Rectangle") )
	{
	    g.setColor(Color.green);
	    g.fillRect(20,20,100,100);
	}
	else if ( toDraw.equals("Oval") )
	{
	    g.setColor(Color.green);
	    g.fillOval(20,20,100,100);
	}
	else if ( toDraw.equals("Face") )
	{
	    g.setColor(Color.black);
	    g.drawOval(20,20,100,100);
	    g.setColor(Color.green);
	    g.fillOval(50,50,2,4);
	    g.fillOval(85,50,2,4);
	    g.setColor(Color.red);
            g.drawLine(50,80,90,80);
            g.drawArc(50,80,40,0,-10,10);
	}
	else if ( toDraw.equals("Clear") )
	{
	    g.setColor(Color.blue);
	    g.clearRect(0,0,WIDTH, HEIGHT);
	}
    }
   
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Rectangle"))
       {
	   toDraw = "Rectangle";
       }
       else if (e.getActionCommand().equals("Oval"))
       {
           toDraw = "Oval";
       }
       else if (e.getActionCommand().equals("Face"))
       {
           toDraw = "Face";
       }
       else if (e.getActionCommand().equals("Clear"))
       {
           toDraw = "Clear";
       }
       else
           toDraw = "Error in button interface.";

       repaint(); //force color and text change
    }

    
   
    private String toDraw = "";
}

