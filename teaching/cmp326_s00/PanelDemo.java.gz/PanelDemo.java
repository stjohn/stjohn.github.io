import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a panel. If you do
 *not see the colored part of the window with text in it, use your
 *mouse to increase the size of the window and it will appear.
 ***************************************************************/
public class PanelDemo extends Frame implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    public static void main(String[] args)
    {
        PanelDemo guiWithPanel = new PanelDemo();
        guiWithPanel.setVisible(true);
    }

    public PanelDemo()
    {
        setTitle("Panel Demonstration");
        setSize(WIDTH, HEIGHT);
        setBackground(Color.blue); 
        addWindowListener(new WindowDestroyer());
   
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.white);

        buttonPanel.setLayout(new FlowLayout());

        Button stopButton = new Button("Red");
        stopButton.setBackground(Color.red); 
        stopButton.addActionListener(this);
        buttonPanel.add(stopButton);

        Button goButton = new Button("Green");
        goButton.setBackground(Color.green);
        goButton.addActionListener(this); 
        buttonPanel.add(goButton);        

        setLayout(new BorderLayout());
        add(buttonPanel, "South");
    }
 
    public void paint(Graphics g)
    {
        g.drawString(theText, 75, 100);
    }
   
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Red"))
        {
            setBackground(Color.red);
            theText = "STOP"; 
        }
        else if (e.getActionCommand().equals("Green"))
        {
           setBackground(Color.green);
           theText = "GO";
        }
        else
            theText = "Error in button interface.";

       repaint(); //force color and text change
    }

    
   
    private String theText = "Watch me!";
}
