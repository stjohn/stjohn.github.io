import java.applet.*;
import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a panel. If you do
 *not see the colored part of the window with text in it, use your
 *mouse to increase the size of the window and it will appear.
 ***************************************************************/
public class FormApplet extends Applet implements ActionListener
{
    public void init()
    {
        setBackground(Color.lightGray); 
   
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.gray);

        buttonPanel.setLayout(new FlowLayout());

        Button doneButton = new Button("Save");
        doneButton.setBackground(Color.lightGray); 
        doneButton.addActionListener(this);
        buttonPanel.add(doneButton);

        Button resetButton = new Button("Clear");
        resetButton.setBackground(Color.lightGray);
        resetButton.addActionListener(this); 
        buttonPanel.add(resetButton);        

        Button retrieveButton = new Button("Retrieve");
        retrieveButton.setBackground(Color.lightGray);
        retrieveButton.addActionListener(this); 
        buttonPanel.add(retrieveButton);        

        setLayout(new BorderLayout());
        add(buttonPanel, "South");

        formPanel = new Panel();
        formPanel.setBackground(Color.gray);
        formPanel.setLayout(new FlowLayout());

        Label firstNameLabel = new Label("First Name: ");
        formPanel.add(firstNameLabel);
        firstNameText = new TextField(15);
        formPanel.add(firstNameText);
        Label lastNameLabel = new Label("Last Name: ");
        formPanel.add(lastNameLabel);
        lastNameText = new TextField(15);
        formPanel.add(lastNameText);
        Label idLabel = new Label("Student ID: ");
        formPanel.add(idLabel);
        idText = new TextField(9);
        formPanel.add(idText);

        add(formPanel, "Center");
    }
 
    public void paint(Graphics g)
    {
        g.drawString(theText, 75, 100);
    }
   
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Save"))
        {
            firstName = firstNameText.getText(); 
            lastName = lastNameText.getText(); 
	    id = Integer.valueOf(idText.getText().trim()).intValue();
        }
        else if (e.getActionCommand().equals("Clear"))
        {
       	    firstNameText.setText(""); 
       	    lastNameText.setText(""); 
       	    idText.setText(""); 
        }
        else if (e.getActionCommand().equals("Retrieve"))
        {
       	    firstNameText.setText(firstName); 
       	    lastNameText.setText(lastName); 
       	    idText.setText(""+id); 
        }
        else
            theText = "Error in button interface.";

        formPanel.repaint(); //force color and text change
    }

    private Panel formPanel;
    private TextField firstNameText;
    private TextField lastNameText;
    private TextField idText;
    private String firstName = "";
    private String lastName = "";
    private int id = 0; 
    private String theText = "Watch me!";
}

