
import java.awt.*; 
import java.awt.event.*;

/******************************************************
 *GUI for totaling a series of numbers. If the user
 *tries to add in a number in an incorrect format,
 *such as 2,000 with a comma, then an error message is
 *generated and the user can restart the computation.
 ****************************************************/
public class ImprovedAdder extends Frame
                           implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 100;


    public static void main(String[] args)
    {
        ImprovedAdder guiAdder = new ImprovedAdder();
        guiAdder.setVisible(true);
    }

    public ImprovedAdder()
    {
        setTitle("Adding Machine");
        addWindowListener(new WindowDestroyer());
        setSize(WIDTH, HEIGHT);

        setLayout(new BorderLayout());

        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.gray);
        buttonPanel.setLayout(new FlowLayout()); 
        Button addButton = new Button("Add In"); 
        addButton.addActionListener(this);
        buttonPanel.add(addButton); 
        Button resetButton = new Button("Reset"); 
        resetButton.addActionListener(this);
        buttonPanel.add(resetButton);
        add(buttonPanel, "South");

        Panel textPanel = new Panel(); 
        textPanel.setBackground(Color.blue); 
        inputOutputField = new TextField("Numbers go here.", 30);
        inputOutputField.setBackground(Color.white);
        textPanel.add(inputOutputField);
        add(textPanel, "Center");
    }



    public void actionPerformed(ActionEvent e) 
    {
        try
        {
            tryingCorrectNumberFormats(e); 
        } 
        catch (NumberFormatException e2)
        { 
            inputOutputField.setText("Error: Reenter Number.");
        }
 
        repaint();
    }
 
    //This method can throw NumberFormatExceptions.
    private void tryingCorrectNumberFormats(ActionEvent e)
    {
        if (e.getActionCommand().equals("Add In"))
        {
            sum = sum +
                stringToDouble(inputOutputField.getText());
            inputOutputField.setText(Double.toString(sum));
        }
        else if (e.getActionCommand().equals("Reset"))
        {
            sum = 0;
            inputOutputField.setText("0.0");
        }
        else 
            inputOutputField.setText("Error in adder code.");
    }
 
    //This method can throw NumberFormatExceptions.
    private static double stringToDouble(String stringObject)
    {
        return Double.valueOf(stringObject.trim()).doubleValue();
    }


    private TextField inputOutputField;
    private double sum = 0;
}


