import java.awt.*; 
import java.util.*; 
import java.awt.event.*;
import java.applet.*;


public class TimeProgramApplet extends Applet implements ActionListener
{
    // The constants used in this program:
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 125;

    // registers the listeners.
    public TimeProgramApplet()
    {
        setLayout(new BorderLayout());
	setBackground(Color.lightGray);
 
	// A panel for the text, that asks for # of pieces:
        textPanel = new Panel(); 
        textPanel.setBackground(Color.gray);

	// The done button-- the listener is this object
	Button doneButton = new Button("Get Current Time");
	doneButton.setBackground(Color.lightGray);
	doneButton.addActionListener(this);
	textPanel.add(doneButton);
        add(textPanel, "South");
    }

    // If the done button is pushed, get the integer from the 
    // textField theText and call repaint to draw the pie to the
    // screen.
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Get Current Time"))
	{
	    Calendar Now = Calendar.getInstance();
	    hour = Now.get(Calendar.HOUR);
	    minutes = Now.get(Calendar.MINUTE);
	}
    
        repaint();//Shows changes in textPanel
    } 

    // Paint the pie and its pieces to the screen:
    public void paint(Graphics g)
    {
	// Make sure the pen color is black:
	g.setColor(Color.black);

	// Draw the circle:
	drawCircle(g, XCENTER, YCENTER, RADIUS);

	// Draw minute hand:
	int xCirc = (int)(Math.cos(2*Math.PI*minutes/60-Math.PI/2)*RADIUS*0.9
		+XCENTER); 
	int yCirc = (int)(Math.sin(2*Math.PI*minutes/60-Math.PI/2)*RADIUS*0.9
		+YCENTER); 
	g.drawLine(XCENTER, YCENTER, xCirc, yCirc);

	// Draw hour hand:
	xCirc = (int)(Math.cos(2*Math.PI*(minutes/60+hour)/12-Math.PI/2)
		*RADIUS*0.6 +XCENTER); 
	yCirc = (int)(Math.sin(2*Math.PI*(minutes/60+hour)/12-Math.PI/2)
		*RADIUS*0.6 +YCENTER); 
	g.drawLine(XCENTER, YCENTER, xCirc, yCirc);

	String toDraw = "The time is " +hour +":";
	if ( minutes < 10 )
	    toDraw = toDraw + "0";
	toDraw = toDraw + minutes;    
	g.drawString(toDraw, 75,250);

    }
 
    // A private method for drawing circles with center (xCenter, yCenter)
    // and radius rad.
    private void drawCircle(Graphics g, int xCenter, int yCenter, int rad)
    {
	g.drawOval(xCenter-rad, yCenter-rad, 2*rad, 2*rad);
    }
 
    private Panel textPanel;
    private TextField theText;
    int minutes, hour;
}
