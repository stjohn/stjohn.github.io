import java.util.*;

public class TimeProgram
{
  public static void main(String[] args)
  {
     //Calendar Now = Calendar.getInstance();
     Calendar Now = new Calendar();
     int hours = Now.get(Calendar.HOUR);
     int minutes = Now.get(Calendar.MINUTE);
     System.out.println("Hours " + hours + " minutes " + minutes);
  }
}
