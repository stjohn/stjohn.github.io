import java.awt.*; 
import java.awt.event.*;

/*
 * This program prompts the user to enter the number of 
 * pieces to be drawn.  When the user clicks the "Done"
 * button, the pie is drawn to the screen.  
 *
 * There is no error checking to make sure the user enters
 * an integer.
 */

public class Lab5 extends Frame implements ActionListener
{
    // The constants used in this program:
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 125;

    public static void main(String[] args)
    {
        Lab5 pieDemo  = new Lab5();
        pieDemo.setVisible(true);
    }

    // The default contructor sets up the textField, label
    // and button.  It also sets background colors and 
    // registers the listeners.
    public Lab5()
    {
	// Set up the frame with title, size, and the 
	// listener for the close button:
        setTitle("Pie Chart Demo");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
	setBackground(Color.lightGray);
        addWindowListener(new WindowDestroyer());
 
	// A panel for the text, that asks for # of pieces:
        textPanel = new Panel(); 
        textPanel.setBackground(Color.gray);

	// The label that tells the user what to enter:
	Label textLabel = new Label("Enter number of pieces:");
	textPanel.add(textLabel);

	// The text field for entering the number:
        theText = new TextField(20);
        theText.setBackground(Color.lightGray);
        textPanel.add(theText);

	// The done button-- the listener is this object
	Button doneButton = new Button("Done");
	doneButton.setBackground(Color.lightGray);
	doneButton.addActionListener(this);
	textPanel.add(doneButton);
        add(textPanel, "South");
    }

    // If the done button is pushed, get the integer from the 
    // textField theText and call repaint to draw the pie to the
    // screen.
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Done"))
	{
	    try
	    {
                numPieces = Integer.valueOf(theText.getText().trim()).
			intValue();
	    }
	    catch (NumberFormatException e2)
	    {
            	theText.setText("Error: Reenter Number");
            }
	}
        else
            theText.setText("Error in memo interface");
    
        repaint();//Shows changes in textPanel
    } 

    // Paint the pie and its pieces to the screen:
    public void paint(Graphics g)
    {
	// Make sure the pen color is black:
	g.setColor(Color.black);

	// Draw the circle:
	drawCircle(g, XCENTER, YCENTER, RADIUS);

	// Draw each piece of the pie:
        for ( int i = 0 ; i < numPieces ; i++ )
	{
	    int xCirc = (int)(Math.cos(2*Math.PI*i/numPieces)*RADIUS+XCENTER); 
	    int yCirc = (int)(Math.sin(2*Math.PI*i/numPieces)*RADIUS+YCENTER); 
	    g.drawLine(XCENTER, YCENTER, xCirc, yCirc);
	}
    }
 
    // A private method for drawing circles with center (xCenter, yCenter)
    // and radius rad.
    private void drawCircle(Graphics g, int xCenter, int yCenter, int rad)
    {
	g.drawOval(xCenter-rad, yCenter-rad, 2*rad, 2*rad);
    }
 
    private Panel textPanel;
    private TextField theText;
    int numPieces = 0;
}
