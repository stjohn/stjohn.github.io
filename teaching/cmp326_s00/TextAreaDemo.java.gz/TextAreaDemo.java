import java.awt.*; 
import java.awt.event.*;

public class TextAreaDemo extends Frame implements ActionListener
{
    public static final int WIDTH = 400;
    public static final int HEIGHT = 300;

    public TextAreaDemo()
    {
        setTitle("Memo Saver");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
 
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(Color.white);
        buttonPanel.setLayout(new FlowLayout());
      
        Button memo1Button = new Button("Save Memo 1"); 
        memo1Button.addActionListener(this);
        buttonPanel.add(memo1Button); 
        Button memo2Button = new Button("Save Memo 2"); 
        memo2Button.addActionListener(this);
        buttonPanel.add(memo2Button);
        Button clearButton = new Button("Clear"); 
        clearButton.addActionListener(this);
        buttonPanel.add(clearButton);
        Button get1Button = new Button("Get Memo 1"); 
        get1Button.addActionListener(this);
        buttonPanel.add(get1Button);
        Button get2Button = new Button("Get Memo 2"); 
        get2Button.addActionListener(this);
        buttonPanel.add(get2Button);

        add(buttonPanel, "South");

        textPanel = new Panel(); 
        textPanel.setBackground(Color.blue);
        theText = new TextArea(10, 40);
        theText.setBackground(Color.white);
        textPanel.add(theText);
        add(textPanel, "Center");
    }

    public void actionPerformed(ActionEvent e) 
    {
        String actionCommand = e.getActionCommand();
        if (actionCommand.equals("Save Memo 1"))
            memo1 = theText.getText();
        else if (actionCommand.equals("Save Memo 2"))
            memo2 = theText.getText();
        else if (actionCommand.equals("Clear"))
            theText.setText("");
        else if (actionCommand.equals("Get Memo 1"))
            theText.setText(memo1);
        else if (actionCommand.equals("Get Memo 2"))
            theText.setText(memo2);
        else
            theText.setText("Error in memo interface");
    
        textPanel.repaint();//Shows changes in textPanel
   } 


 
    public static void main(String[] args)
    {
        TextAreaDemo guiMemo = new TextAreaDemo();
        guiMemo.setVisible(true);
    }
 
    private Panel textPanel;
    private TextArea theText;
    private String memo1 = "No Memo 1.";
    private String memo2 = "No Memo 2.";
}
