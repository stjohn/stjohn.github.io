import java.io.*;
public class TextFileInputDemo
{
    public static void main(String[] args)
    {
       try
       {
           BufferedReader inputStream = null;
           inputStream = 
               new BufferedReader(new FileReader("data.txt"));

           String line = null;
           line = inputStream.readLine();
           System.out.println("The first line in data.txt is:");
           System.out.println(line);
        
           line = inputStream.readLine();
           System.out.println("The second line in data.txt is:");
           System.out.println(line); 
           inputStream.close();
       }
       catch(FileNotFoundException e)
       {
           System.out.println("File data.txt not found.");
       }
       catch(IOException e2)
       {
           System.out.println("Error reading from file data.txt.");
       }
    }
}

