import java.io.*;

/********************************************************
 *Class for data on employees.
 *This is a new, improved definition of the class Employee, 
 *which allows I/O from files
 *********************************************************/

public class Employee
{
    public Employee()
    {
        name = null;
        ssNumber = 0;
        salary = 0;
    }

    public Employee(String theName, int theSSN,
                                   double theSalary)
    {
        name = theName;
        if (theSSN >= 0)
            ssNumber = theSSN;
        else
        {
            System.out.println("ERROR: can't have a negative social "
		+ "security number.");
            System.exit(0);
        }
        salary = theSalary;
    } 

    public void set(String newName, int newSSN,
                                    double newSalary)
    {
        name = newName;
        if (newSSN >= 0)
            ssNumber = newSSN;
        else
        {
            System.out.println("ERROR: can't have a negative "
		+ " social security number.");
            System.exit(0);
        }
        salary = newSalary;
    }

    public String getName()
    {
        return name;
    }

    public int getSSN()
    {
        return ssNumber;
    }

    public double getSalary()
    {
        return salary;
    }

    /****************************************************
     *Two objects are equal if they have the same name and
     *social security number (even if they have different
     *salaries).
     ***************************************************/
    public boolean equals(Employee otherObject)
    {
        return ((name.equalsIgnoreCase(otherObject.name))
                && (ssNumber == otherObject.ssNumber));
    }

     /*******************************
      *Takes input from the keyboard.
      *******************************/
     public void readInput()
     {
        System.out.println("What is the employee's name?"); 
        name = SavitchIn.readLine();
        System.out.println("What is their social security number?");
        ssNumber = SavitchIn.readLineInt(); 
        System.out.println("Enter their salary:");
        salary = SavitchIn.readLineDouble(); 
    }

    /*************************************************************
     *Precondition: The stream inputStream is connected to a file.
     *Each employee record appears in the file as three items,
     *IN THIS ORDER: a String for the name, an int for the 
     *social security number, and a double for the salary.
     *Action: Reads a record from the stream and resets the data
     *for the calling object. An attempt to read past the end 
     *of the file will throw an EOFException. 
     ************************************************************/
    public void readInput(DataInputStream inputStream)
                                               throws IOException
    {
        name = inputStream.readUTF(); 
        ssNumber = inputStream.readInt(); 
        salary = inputStream.readDouble(); 
    }
    
    /*******************************
     *Sends output to the screen.
     *******************************/
    public void writeOutput()
    {
         System.out.println("Name = " + name); 
         System.out.println("SSN = " + ssNumber); 
         System.out.println("Growth rate = " + salary + "%");
    }
 
 
    /*********************************************************
     *Precondition: The stream outputStream has been connected
     *to a file.
     *Action: A record of the species is written to the file
     *that is connected to outputStream. The record is written
     *as three items, IN THIS ORDER: a String for the name, an
     *int for the social security number, and a double for the 
     *salary.
     *********************************************************/
    public void writeOutput(DataOutputStream outputStream)
                                             throws IOException
    {
         outputStream.writeUTF(name); 
         outputStream.writeInt(ssNumber); 
         outputStream.writeDouble(salary); 
    }

    private String name;	//The employee's name
    private int ssNumber;	//The employee's Social Security Number
    private double salary;  	//The employee's salary
}



