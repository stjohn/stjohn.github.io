# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


$key = q/{displaymath}(1<mboxcount<10){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="1" HEIGHT="31"
 SRC="img1.gif"
 ALT="\begin{displaymath}
(1 < \mbox{count} < 10)
 \end{displaymath}">|; 

1;

