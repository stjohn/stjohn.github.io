import java.applet.*;
import java.awt.*; 
import java.awt.event.*;

/*
 * This program prompts the user to enter the number of 
 * pieces to be drawn.  When the user clicks the "Done"
 * button, the pie is drawn to the screen.  
 *
 * There is no error checking to make sure the user enters
 * an integer.
 */

public class FirstApplet extends Applet implements ActionListener
{
    // The constants used in this program:
    public static final int WIDTH = 300;   
    public static final int HEIGHT = 300;
    public static final int RADIUS = 75;
    public static final int XCENTER = 150;
    public static final int YCENTER = 125;


    public void init()
    {
	// Set up the frame with title, size, and the listener
	// for the close button:
        setLayout(new BorderLayout());
	setBackground(Color.lightGray);
 
	// A panel for the text, that asks for # of pieces:
        textPanel = new Panel(); 
        textPanel.setBackground(Color.gray);

	// The label that tells the user what to enter:
	Label textLabel = new Label("Enter number of pieces:");
	textPanel.add(textLabel);

	// The text field for entering the number:
        theText = new TextField(3);
        theText.setBackground(Color.lightGray);
        textPanel.add(theText);

	// The done button-- the listener is this object
	Button doneButton = new Button("Done");
	doneButton.setBackground(Color.lightGray);
	doneButton.addActionListener(this);
	textPanel.add(doneButton);
        add(textPanel, "South");
    }

    // If the done button is pushed, get the integer from the 
    // textField theText and call repaint to draw the pie to the
    // screen.
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getActionCommand().equals("Done"))
	{
            numPieces = Integer.valueOf(theText.getText().trim()).intValue();
	}
        else
            theText.setText("Error in memo interface");
    
        repaint();//Shows changes in textPanel
    } 

    // Paint the pie and its pieces to the screen:
    public void paint(Graphics g)
    {
	// Make sure the pen color is black:
	g.setColor(Color.black);

	// Draw the circle:
	//drawCircle(g, XCENTER, YCENTER, RADIUS);

	// Draw each piece of the pie:
            for ( int j = 0 ; j < numPieces ; j++)
            {
	        int x2 = (int)(Math.cos(2*Math.PI*j/numPieces)*RADIUS+XCENTER); 
	        int y2 = (int)(Math.sin(2*Math.PI*j/numPieces)*RADIUS+YCENTER); 
	        g.drawLine(XCENTER+RADIUS, YCENTER, x2, y2);
	    }
    }
 
    // A private method for drawing circles with center (xCenter, yCenter)
    // and radius rad.
    private void drawCircle(Graphics g, int xCenter, int yCenter, int rad)
    {
	g.drawOval(xCenter-rad, yCenter-rad, 2*rad, 2*rad);
    }
 
    private Panel textPanel;
    private TextField theText;
    int numPieces = 0;
}
