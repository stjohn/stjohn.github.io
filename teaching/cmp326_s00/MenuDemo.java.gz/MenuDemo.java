import java.awt.*; 
import java.awt.event.*;

/**************************************************
 *GUI for saving and retrieving memos using a menu.
 **************************************************/
public class MenuDemo extends Frame implements ActionListener
{
    public static final int WIDTH = 500;
    public static final int HEIGHT = 500;

    public MenuDemo()
    {
        setTitle("Memo Saver");
        setSize(WIDTH, HEIGHT);
        setBackground(Color.blue);
        addWindowListener(new WindowDestroyer());

        Menu memoMenu = new Menu("Memos");
        MenuItem m; 
        m = new MenuItem("Save Memo 1"); 
        m.addActionListener(this);
        memoMenu.add(m); 

        m = new MenuItem("Save Memo 2"); 
        m.addActionListener(this);
        memoMenu.add(m); 

        m = new MenuItem("Get Memo 1"); 
        m.addActionListener(this);
        memoMenu.add(m); 

        m = new MenuItem("Get Memo 2"); 
        m.addActionListener(this);
        memoMenu.add(m); 

        m = new MenuItem("Clear"); 
        m.addActionListener(this);
        memoMenu.add(m); 

        m = new MenuItem("Exit"); 
        m.addActionListener(this);
        memoMenu.add(m);
      
        MenuBar mBar = new MenuBar();
        mBar.add(memoMenu);
        setMenuBar(mBar);
          
        Panel textPanel = new Panel();
        textPanel.setBackground(Color.blue);
        theText = new TextArea(20, 50);
        theText.setBackground(Color.white);
        textPanel.add(theText);
        setLayout(new FlowLayout());
        add(textPanel);
    }

    public void actionPerformed(ActionEvent e) 
    {
        String actionCommand = e.getActionCommand();
        if (actionCommand.equals("Save Memo 1"))
            memo1 = theText.getText();
        else if (actionCommand.equals("Save Memo 2"))
            memo2 = theText.getText();
        else if (actionCommand.equals("Clear"))
            theText.setText("");
        else if (actionCommand.equals("Get Memo 1"))
            theText.setText(memo1);
        else if (actionCommand.equals("Get Memo 2"))
            theText.setText(memo2);
        else if (actionCommand.equals("Exit"))
            System.exit(0);
        else 
            theText.setText("Error in memo interface.");
            
       repaint();
   } 

   
    public static void main(String[] args)
    {
        MenuDemo menuGUI = new MenuDemo();
        menuGUI.setVisible(true);
    }
   
    private TextArea theText;
    private String memo1 = "No Memo 1.";
    private String memo2 = "No Memo 2.";
}

