import java.util.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MousePlay2 extends Frame implements MouseListener
{  
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    private Vector boxesToDraw = new Vector();
    

    public static void main(String[] args)
    {
        MousePlay2 myFrame = new MousePlay2();
        myFrame.setVisible(true);
    }

    public MousePlay2()
    {  
        setTitle("Mouse Spy");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
        addMouseListener(this);

        //Make sure there's at least one box to draw:
	boxesToDraw.addElement(new Integer(WIDTH/2));
	boxesToDraw.addElement(new Integer(HEIGHT/2));
    }

    public void paint(Graphics g)
    {
	g.setColor(Color.cyan);
	for (int i = 0 ; i < boxesToDraw.size(); i+=2)
	{
	    Integer xObj = (Integer) boxesToDraw.elementAt(i);
	    Integer yObj = (Integer) boxesToDraw.elementAt(i+1);
	    int nextX = xObj.intValue();
	    int nextY = yObj.intValue();
	    g.fillRect(nextX, nextY, 10, 10);
	}
    }

    public void mouseClicked(MouseEvent event)
    {  System.out.println("Mouse clicked. x = " 
             + event.getX() + " y = " + event.getY());
	boxesToDraw.addElement(new Integer(event.getX()));
	boxesToDraw.addElement(new Integer(event.getY()));
        repaint();
    }

    public void mouseEntered(MouseEvent event)
    {  System.out.println("Mouse entered. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mouseExited(MouseEvent event)
    {  System.out.println("Mouse exited. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mousePressed(MouseEvent event)
    {  System.out.println("Mouse pressed. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mouseReleased(MouseEvent event)
    {  System.out.println("Mouse released. x = " 
             + event.getX() + " y = " + event.getY());
    }
}
