import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class ConnectTheDots extends Frame 
	implements MouseListener, ActionListener
{  
    //The size of the frame:
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    //A stack to hold the coordinates of the dots to draw:
    private Stack dotsToDraw = new Stack();
    
    //Sets up the frame and makes it visible on screen:
    public static void main(String[] args)
    {
        ConnectTheDots myFrame = new ConnectTheDots();
        myFrame.setVisible(true);
    }

    //The default constructor sets the size and title for the frame
    //and places one "dot" (at the center of the frame) into the stack. 
    //This makes the opening screen has at one dot on it.
    public ConnectTheDots()
    {  
        setTitle("Connect the Dots");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
        addMouseListener(this);

        //Make sure there's at least one dot to draw:
	dotsToDraw.addElement(new Integer(WIDTH/2));
	dotsToDraw.addElement(new Integer(HEIGHT/2));
    }

    //For each dot, draw the dot, and then draw a line from
    //it to the previous dot.
    public void paint(Graphics g)
    {
	int nextX = 0, nextY = 0, oldX = 0, oldY = 0;

	g.setColor(Color.cyan);
	for (int i = 0 ; i < dotsToDraw.size(); i+=2)
	{
	    Integer xObj = (Integer) dotsToDraw.elementAt(i);
	    Integer yObj = (Integer) dotsToDraw.elementAt(i+1);
	    if ( i == 0 )
	    {
		//The first time through, there's no old dot, so set
		//it the same as the new dot.
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
		oldX = nextX;
		oldY = nextY;
	    }
	    else
	    {
		//Otherwise, there's a dot from the last time through,
		//so save it as the old dot and get the next dot.
		oldX = nextX;
		oldY = nextY;
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
	    }
	    //Draw the dot:
	    g.fillRect(nextX, nextY, 10, 10);
	    //Draw the line:
	    g.drawLine(oldX, oldY, nextX, nextY);
	}
    }

    //There's no components (like buttons or menus) to generate
    //action events, so, this method is empty.
    public void actionPerformed(ActionEvent e)
    {
    }

    //When the mouse is clicked, write the coordinates to the console
    //window and push them (wrapped as objects) onto the dotsToDraw
    //stack.
    public void mouseClicked(MouseEvent event)
    {  System.out.println("Mouse clicked. x = " 
             + event.getX() + " y = " + event.getY());
	dotsToDraw.addElement(new Integer(event.getX()));
	dotsToDraw.addElement(new Integer(event.getY()));
        repaint();
    }

    //When the mouse enters the frame, write the coordinates to the
    //console window.
    public void mouseEntered(MouseEvent event)
    {  System.out.println("Mouse entered. x = " 
             + event.getX() + " y = " + event.getY());
    }

    //When the mouse exits the frame, write the coordinates to the
    //console window.
    public void mouseExited(MouseEvent event)
    {  System.out.println("Mouse exited. x = " 
             + event.getX() + " y = " + event.getY());
    }

    //When the mouse is pressed, write the coordinates to the
    //console window.
    public void mousePressed(MouseEvent event)
    {  System.out.println("Mouse pressed. x = " 
             + event.getX() + " y = " + event.getY());
    }

    //When the mouse is released, write the coordinates to the
    //console window.
    public void mouseReleased(MouseEvent event)
    {  System.out.println("Mouse released. x = " 
             + event.getX() + " y = " + event.getY());
    }
}
