import java.util.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MousePlay3 extends Frame implements MouseListener
{  
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    private Stack boxesToDraw = new Stack();
    

    public static void main(String[] args)
    {
        MousePlay3 myFrame = new MousePlay3();
        myFrame.setVisible(true);
    }

    public MousePlay3()
    {  
        setTitle("Connect the Dots");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
        addMouseListener(this);

        //Make sure there's at least one box to draw:
	boxesToDraw.addElement(new Integer(WIDTH/2));
	boxesToDraw.addElement(new Integer(HEIGHT/2));
    }

    public void paint(Graphics g)
    {
	int nextX = 0, nextY = 0, oldX = 0, oldY = 0;

	g.setColor(Color.cyan);
	for (int i = 0 ; i < boxesToDraw.size(); i+=2)
	{
	    Integer xObj = (Integer) boxesToDraw.elementAt(i);
	    Integer yObj = (Integer) boxesToDraw.elementAt(i+1);
	    if ( i == 0 )
	    {
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
		oldX = nextX;
		oldY = nextY;
	    }
	    else
	    {
		oldX = nextX;
		oldY = nextY;
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
	    }
	    g.fillRect(nextX, nextY, 10, 10);
	    g.drawLine(oldX, oldY, nextX, nextY);
	}
    }

    public void mouseClicked(MouseEvent event)
    {  
	boxesToDraw.addElement(new Integer(event.getX()));
	boxesToDraw.addElement(new Integer(event.getY()));
        repaint();
    }

    public void mouseEntered(MouseEvent event)
    {  
    }

    public void mouseExited(MouseEvent event)
    {  
    }

    public void mousePressed(MouseEvent event)
    {  
    }

    public void mouseReleased(MouseEvent event)
    {  
    }
}
