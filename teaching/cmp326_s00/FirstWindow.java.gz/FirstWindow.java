import java.awt.*;
import java.awt.event.*;

public class FirstWindow extends Frame
{
    public static final int WIDTH = 300; 
    public static final int HEIGHT = 200;

    /*********************************************************
     *A simple demonstration of a window constructed with AWT.
     **********************************************************/
    public static void main(String[] args)
    {
        FirstWindow myWindow = new FirstWindow();
        myWindow.setSize(WIDTH, HEIGHT);

        WindowDestroyer listener = new WindowDestroyer();
        myWindow.addWindowListener(listener);

        myWindow.setVisible(true);
    }

    public void paint(Graphics g)
    {
        g.drawString("Please, don't click that button!", 75, 100); 
    }
}

