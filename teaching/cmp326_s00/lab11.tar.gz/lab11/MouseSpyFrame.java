import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseSpyFrame extends Frame
{  
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    public static void main(String[] args)
    {
        MouseSpyFrame myFrame = new MouseSpyFrame();
        myFrame.setVisible(true);
    }

    public MouseSpyFrame()
    {  
        setTitle("Mouse Spy");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());

        MouseSpy listener = new MouseSpy();
        addMouseListener(listener);
    }

    private class MouseSpy implements MouseListener
    {  
        public void mouseClicked(MouseEvent event)
        {  System.out.println("Mouse clicked. x = " 
         + event.getX() + " y = " + event.getY());
        }

        public void mouseEntered(MouseEvent event)
        {  System.out.println("Mouse entered. x = " 
         + event.getX() + " y = " + event.getY());
        }

        public void mouseExited(MouseEvent event)
        {  System.out.println("Mouse exited. x = " 
             + event.getX() + " y = " + event.getY());
        }

        public void mousePressed(MouseEvent event)
        {  System.out.println("Mouse pressed. x = " 
             + event.getX() + " y = " + event.getY());
        }

        public void mouseReleased(MouseEvent event)
        {  System.out.println("Mouse released. x = " 
             + event.getX() + " y = " + event.getY());
        }
    }
}
