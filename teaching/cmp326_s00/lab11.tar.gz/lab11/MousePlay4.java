import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class MousePlay4 extends Frame implements MouseListener, ActionListener
{  
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    private Stack boxesToDraw = new Stack();
    

    public static void main(String[] args)
    {
        MousePlay4 myFrame = new MousePlay4();
        myFrame.setVisible(true);
    }

    public MousePlay4()
    {  
        setTitle("Connect the Dots");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
        addMouseListener(this);

        //Make sure there's at least one box to draw:
	boxesToDraw.push(new Integer(WIDTH/2));
	boxesToDraw.push(new Integer(HEIGHT/2));


	//Set up panel and button:
	Panel buttonPanel = new Panel();
	buttonPanel.setBackground(Color.blue);
	Button unDoButton = new Button("Undo");
	unDoButton.setBackground(Color.cyan);
	unDoButton.addActionListener(this);
	buttonPanel.add(unDoButton);
	add(buttonPanel, "South");
    }

    public void paint(Graphics g)
    {
	int nextX = 0, nextY = 0, oldX = 0, oldY = 0;

	g.setColor(Color.cyan);
	for (int i = 0 ; i < boxesToDraw.size(); i+=2)
	{
	    Integer xObj = (Integer) boxesToDraw.elementAt(i);
	    Integer yObj = (Integer) boxesToDraw.elementAt(i+1);
	    if ( i == 0 )
	    {
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
		oldX = nextX;
		oldY = nextY;
	    }
	    else
	    {
		oldX = nextX;
		oldY = nextY;
	        nextX = xObj.intValue();
	        nextY = yObj.intValue();
	    }
	    g.fillRect(nextX, nextY, 10, 10);
	    g.drawLine(oldX, oldY, nextX, nextY);
	}
    }

    public void actionPerformed(ActionEvent e)
    {
	if (e.getActionCommand().equals("Undo"))
	{
	    boxesToDraw.pop();
	    boxesToDraw.pop();
	}
	repaint();
    }

    public void mouseClicked(MouseEvent event)
    {  
	boxesToDraw.push(new Integer(event.getX()));
	boxesToDraw.push(new Integer(event.getY()));
        repaint();
    }

    public void mouseEntered(MouseEvent event)
    {  
    }

    public void mouseExited(MouseEvent event)
    {  
    }

    public void mousePressed(MouseEvent event)
    {  
    }

    public void mouseReleased(MouseEvent event)
    {  
    }
}
