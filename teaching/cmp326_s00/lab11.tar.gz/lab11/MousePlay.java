import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MousePlay extends Frame implements MouseListener
{  
    public static final int WIDTH = 400;   
    public static final int HEIGHT = 300;

    private int myX = WIDTH/2;
    private int myY = HEIGHT/2;

    public static void main(String[] args)
    {
        MousePlay myFrame = new MousePlay();
        myFrame.setVisible(true);
    }

    public MousePlay()
    {  
        setTitle("Mouse Spy");
        setLayout(new BorderLayout());
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());

        addMouseListener(this);
    }

    public void paint(Graphics g)
    {
	g.setColor(Color.cyan);
	g.fillRect(myX, myY, 10, 10);
    }

    public void mouseClicked(MouseEvent event)
    {  System.out.println("Mouse clicked. x = " 
             + event.getX() + " y = " + event.getY());
           myX = event.getX();
           myY = event.getY();
           repaint();
    }

    public void mouseEntered(MouseEvent event)
    {  System.out.println("Mouse entered. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mouseExited(MouseEvent event)
    {  System.out.println("Mouse exited. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mousePressed(MouseEvent event)
    {  System.out.println("Mouse pressed. x = " 
             + event.getX() + " y = " + event.getY());
    }

    public void mouseReleased(MouseEvent event)
    {  System.out.println("Mouse released. x = " 
             + event.getX() + " y = " + event.getY());
    }
}
