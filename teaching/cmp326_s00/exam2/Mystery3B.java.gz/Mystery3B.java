import java.awt.*; 
import java.awt.event.*;

public class Mystery3B extends Frame 
{
    public static final int WIDTH = 300;   
    public static final int HEIGHT = 200;

    public static void main(String[] args)
    {
        Mystery3B demo  = new Mystery3B();
        demo.setVisible(true);
    }

    public Mystery3B()
    {
        setSize(WIDTH, HEIGHT);
        addWindowListener(new WindowDestroyer());
    }

    public void paint(Graphics g)
    {
	g.setColor(Color.black);
        for ( int i = 1 ; i <= 3 ; i++ )
	{
	    g.drawRect(10*i, 10*i, 100, 100);
	}
    }
}
