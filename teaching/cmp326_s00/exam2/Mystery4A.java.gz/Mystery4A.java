import java.io.*;
public class Mystery4A
{  public static void main(String[] args)
   {  try
      {  BufferedReader inputStream = 
             new BufferedReader(new FileReader("story.txt"));
         PrintWriter outputStream =
             new PrintWriter(new FileOutputStream("storylines.txt"));
         int count = 0;
         String line = inputStream.readLine();
         while (line != null)
         {  count++;
	    if ( count % 2 == 0 )
                System.out.println(line);
            else
                outputStream.println(line);
            line = inputStream.readLine(); 
         }
         inputStream.close();
         outputStream.close();
      }
      catch(FileNotFoundException e)
      {  System.out.println("File story.txt not found."); }
      catch(IOException e2)
      {  System.out.println("Error reading from file story.txt."); }
   }
}
