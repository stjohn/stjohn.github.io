import java.awt.*;
import java.awt.event.*;

public class WindowTest extends Frame
{
    public static final int WIDTH = 300; 
    public static final int HEIGHT = 200;

    /*********************************************************
     *A simple demonstration of a window constructed with AWT.
     **********************************************************/
    public static void main(String[] args)
    {
        FirstWindow myWindow = new FirstWindow();
        FirstWindow myWindow2 = new FirstWindow();
        myWindow.setSize(WIDTH, HEIGHT);
        myWindow2.setSize(WIDTH, HEIGHT);

        WindowDestroyer listener = new WindowDestroyer();
        myWindow.addWindowListener(listener);
        myWindow2.addWindowListener(listener);

        myWindow.setVisible(true);
        myWindow2.setVisible(true);
    }

    public void paint(Graphics g)
    {
        g.drawString("Please, don't click that button!", 75, 100); 
    }
}

