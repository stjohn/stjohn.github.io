import java.awt.*; 
import java.awt.event.*;

/***************************************************************
 *Simple demonstration of putting buttons in a container class.
 ***************************************************************/
public class Tally extends Frame implements ActionListener
{
    public static final int WIDTH = 300;
    public static final int HEIGHT = 200;

    /**********************************************************
     *Creates and displays a window of the class Tally.
     ***********************************************************/
    public static void main(String[] args)
    {
        Tally buttonGui = new Tally();
        buttonGui.setVisible(true);
    }


    public Tally()
    {
        setSize(WIDTH, HEIGHT);

        addWindowListener(new WindowDestroyer()); 
        setTitle("Tally");
        setBackground(Color.blue);
 
        setLayout(new FlowLayout());

        Button stopButton = new Button("Add 1"); 
        stopButton.addActionListener(this);
        add(stopButton);

        Button goButton = new Button("Minus 1");
        goButton.addActionListener(this); 
        add(goButton);        
    }

    public void paint(Graphics g)
    {
        g.drawString(theText, 75, 100);
    }
 
    public void actionPerformed(ActionEvent e) 
    {
       if (e.getActionCommand().equals("Add 1"))
       {
            tallyCount++; 
	    theText = theText + "1";
       }
       else if (e.getActionCommand().equals("Minus 1"))
       {
	   if (tallyCount > 0 )
	   {
               tallyCount--;
               theText = theText.substring(0, theText.length()-1);
           }
       }
       else
           theText = "Error in button interface.";

       repaint(); //force color and text change
    }
 
 
    private String theText = "";
    private int tallyCount = 0;
}

