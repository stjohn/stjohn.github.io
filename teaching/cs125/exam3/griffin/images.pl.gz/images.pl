# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{displaymath}left(arraycc1&23&45&6arrayright)isleft(arrayccc1&3&52&4&6arrayright){displaymath}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="73"
 SRC="img2.gif"
 ALT="\begin{displaymath}\left (
\begin{array}{cc}
1 & 2\\\\
3 & 4\\\\
5 & 6\\\\
\end{arr...
...{array}{ccc}
1 & 3 & 5\\\\
2 & 4 & 6\\\\
\end{array} \right ) \end{displaymath}">|; 

1;

